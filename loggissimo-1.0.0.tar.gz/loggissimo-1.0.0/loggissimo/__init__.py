from ._logger import Logger, Level

logger = Logger()

__version__ = "0.2.16.dev1"
