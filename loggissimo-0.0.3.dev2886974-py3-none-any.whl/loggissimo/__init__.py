from ._logger import Logger
from .constants import Level

logger = Logger(disable_threads=True)

__version__ = "0.0.3.dev2886974"
