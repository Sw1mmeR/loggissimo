from ._logger import Logger, Level

logger = Logger()

__version__ = "1.0.4"
