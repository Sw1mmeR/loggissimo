from ._logger import Logger
from .constants import Level

logger = Logger()

__version__ = "0.0.2"
